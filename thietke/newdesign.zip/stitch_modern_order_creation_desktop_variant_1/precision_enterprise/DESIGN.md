---
name: Precision Enterprise
colors:
  surface: '#f7fafd'
  surface-dim: '#d7dadd'
  surface-bright: '#f7fafd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f7'
  surface-container: '#ebeef1'
  surface-container-high: '#e5e8eb'
  surface-container-highest: '#e0e3e6'
  on-surface: '#181c1e'
  on-surface-variant: '#434654'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eef1f4'
  outline: '#737685'
  outline-variant: '#c3c6d6'
  surface-tint: '#0c56d0'
  primary: '#003d9b'
  on-primary: '#ffffff'
  primary-container: '#0052cc'
  on-primary-container: '#c4d2ff'
  inverse-primary: '#b2c5ff'
  secondary: '#525f73'
  on-secondary: '#ffffff'
  secondary-container: '#d6e3fb'
  on-secondary-container: '#586579'
  tertiary: '#004e33'
  on-tertiary: '#ffffff'
  tertiary-container: '#006846'
  on-tertiary-container: '#5debaf'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b2c5ff'
  on-primary-fixed: '#001848'
  on-primary-fixed-variant: '#0040a2'
  secondary-fixed: '#d6e3fb'
  secondary-fixed-dim: '#bac7de'
  on-secondary-fixed: '#0f1c2d'
  on-secondary-fixed-variant: '#3b485a'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f7fafd'
  on-background: '#181c1e'
  surface-variant: '#e0e3e6'
typography:
  headline-xl:
    fontFamily: Manrope
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-tabular:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-padding: 24px
  gutter: 16px
  card-gap: 20px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style
The design system is engineered for the high-stakes environment of Enterprise Resource Planning (ERP). It prioritizes **clarity, speed of cognition, and unwavering reliability**. The visual language is rooted in **Corporate Modernism**, utilizing a structured grid and a sophisticated color palette to manage complex data densities without overwhelming the user.

The brand personality is professional and authoritative, yet accessible. It avoids unnecessary decoration in favor of functional aesthetics—utilizing subtle depth, generous whitespace, and a clear information hierarchy to guide business users through critical workflows like order creation and inventory management.

## Colors
The palette is dominated by **Professional Blue**, used strategically for primary actions and brand presence. The neutral foundation uses a light grey canvas to reduce eye strain during long working sessions.

- **Primary (#0052CC):** Used for main CTAs, active states, and focus indicators.
- **Secondary / Slate Grey (#475467):** Primary choice for body text, icons, and sidebar navigation to ensure high legibility and a grounded feel.
- **Surface:** Pure white is reserved for cards and containers to pop against the light grey background.
- **Success/Semantic:** A vibrant green (#10B981) is used for positive status indicators and promotions.

## Typography
This design system uses **Manrope** for its modern, geometric construction that maintains excellent legibility at small sizes—crucial for data-heavy ERP tables.

- **Headlines:** Use Bold or Semi-Bold weights to provide clear section anchoring.
- **Body:** Standardized at 14px for general data entry to balance density and readability.
- **Tabular Data:** Use `tabular-nums` for all price and quantity columns in tables to ensure vertical alignment of digits.
- **Labels:** Small, uppercase labels with slight letter spacing are used for form field headers and table headers to distinguish them from user-generated content.

## Layout & Spacing
The layout follows a **Fixed-Fluid hybrid grid**. The sidebar remains fixed at 240px (collapsed to 72px), while the main content area utilizes a fluid 12-column grid.

- **Margins:** 24px outer margins for desktop screens.
- **Gaps:** A consistent 20px vertical gap between content cards.
- **Density:** We utilize a "Comfortable" density for general forms and a "Compact" density for data tables to allow more information to be visible above the fold.
- **Breakpoints:** 
    - Mobile (< 768px): Single column, cards stack vertically. 
    - Tablet (768px - 1280px): 12-column grid, sidebar often hidden behind a hamburger menu.
    - Desktop (> 1280px): Full 12-column grid with persistent sidebar.

## Elevation & Depth
Depth is created through **Tonal Layering** and soft, ambient shadows. This approach keeps the interface looking clean and flat while providing necessary cues about interactable surfaces.

- **Level 0 (Canvas):** #F4F7FA. The lowest layer.
- **Level 1 (Cards/Surface):** #FFFFFF with a 1px border (#E4E7EC) and a soft shadow (0px 4px 6px -2px rgba(16, 24, 40, 0.03)).
- **Level 2 (Active/Modals):** More pronounced shadow (0px 12px 16px -4px rgba(16, 24, 40, 0.08)) to indicate temporary overlays or pulled-out summary panels.
- **Outlines:** Subtle 1px borders are used on all input fields and table rows to provide structure without visual noise.

## Shapes
The design system employs a **Rounded (Level 2)** shape language. This softens the "industrial" feel of typical ERP software, making the tool feel more modern and approachable.

- **Base Radius:** 8px for small components (inputs, buttons).
- **Container Radius:** 12px for cards, panels, and large sections.
- **Pill Radius:** Used exclusively for status tags (e.g., "Active", "Draft") and selection indicators.

## Components
Consistent component behavior is vital for efficiency in high-frequency data entry tasks.

- **Buttons:** 
    - **Primary:** Solid blue with white text. 
    - **Secondary:** White background with blue border and text. 
    - **Ghost:** No border, grey text; turns subtle grey on hover.
- **Input Fields:** 12px padding with 8px corner radius. Focus state uses a 2px blue ring. Labels are positioned consistently above the input.
- **Tables:** 
    - No vertical lines; use horizontal 1px light grey borders (#F2F4F7) between rows. 
    - Header rows have a subtle grey background (#F9FAFB).
    - Row hover state uses a very faint blue tint (#F5F9FF).
- **Cards:** 12px rounded corners, white background, and a subtle drop shadow. Every major functional block (General Info, Product List) must be wrapped in a card.
- **Sidebar:** Dark Slate (#101828) or very light grey based on user preference, with active states marked by a 4px vertical bar and a primary blue icon/text.
- **Summary Panel:** Often sticky or placed on the right, using a slightly different background tint or a bold color (as seen in the Order Summary) to highlight finality.